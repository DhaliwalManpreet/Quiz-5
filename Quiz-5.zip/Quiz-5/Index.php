<?php 
	
	class Index
	{
		public function getIndexes(){
			$dbcon = Database::getDb();
			$sql = "SELECT * FROM cds";
			
			$pdostm = $dbcon->prepare($sql); 
			$pdostm->execute();
			$indexes = $pdostm->fetchAll(PDO::FETCH_OBJ);
			return $indexes;
		}
		public function CreateIndex($titel, $interpret, $jahr){
			$db = Database::getDb();
			$sql = "INSERT INTO cds (titel, interpret, jahr)
				values(:titel, :interpret, :jahr)";				
			$pst = $db->prepare($sql);
			$pst->bindParam(':titel',$titel);
			$pst->bindParam(':interpret',$interpret);
			$pst->bindParam(':jahr',$jahr);
			
			$count= $pst->execute();
			echo $count;
		}
	}
?>