<?php 
	require_once 'database.php';
	require_once 'Index.php';
	
	$dbcon = Database::getDb();
	$s = new Index();
	$myIndex = $s->getIndexes(Database::getDb());
		//echo "<b>titel</b>". "<b>     interpret</b>"."<b>     jahr</b>";
	foreach($myIndex as $index){
		
		echo "<li>".$index->titel." ".$index->interpret." ".$index->jahr ."</li>";
	}
?>